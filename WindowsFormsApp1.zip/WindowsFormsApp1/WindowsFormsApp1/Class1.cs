﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Alumnos
    {

        private string Nombre;
        private string Apellido;
        private string Email;
        private string Ciudad;
        private string Provincia;
        private int Legajo;
        static int Ultimolegajo;
        private int anioIngreso;
        private bool Activo;
        private string Domicilio;
        private string Telefono;


        public Alumnos(){
            Ultimolegajo += 1;
            Legajo = Ultimolegajo;
            anioIngreso = DateTime.Now.Year;
        }

        public Alumnos(string Aapellido, string Anombre):this() 
        {
            
            Apellido = Aapellido;
            Nombre = Anombre;
            Ciudad = "san francisco";
            Provincia = "cordoba";
            Activo = true;
        }
        public Alumnos(bool Aactivo, string Aapellido, string Anombre, string Aemail, string Aciudad, string Aprovincia, string Adomicilio, string Atelefono ) : this()
        {

            Apellido = Aapellido;
            Nombre = Anombre;
            Email = Aemail;
            Ciudad = Aciudad;
            Provincia = Aprovincia;
            Apellido = Adomicilio;
            Telefono = Atelefono;
            Activo = Aactivo;


        }
        public override string ToString()
        {
            string mensaje="";
            mensaje += "legajo " + Legajo + "\n";
            mensaje += "año ingreso " + anioIngreso + "\n";
            mensaje += "nombre " + Nombre + "\n";
            mensaje += "apellido " + Apellido+ "\n";
            mensaje += "ciudad " + Ciudad+ "\n";
            mensaje += "provincia " + Provincia+ "\n";
            if ( Activo ) { mensaje += "activo \n"; }
            else{ mensaje += "no activo \n"; }

            return mensaje;
        }

    }
}
